-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 01, 2021 at 11:38 PM
-- Server version: 10.4.16-MariaDB
-- PHP Version: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `takhfifsensor`
--

-- --------------------------------------------------------

--
-- Table structure for table `banners`
--

CREATE TABLE `banners` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_id` bigint(20) UNSIGNED DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('short_top','long_top','bottom') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `banners`
--

INSERT INTO `banners` (`id`, `name`, `image_id`, `url`, `type`, `created_at`, `updated_at`) VALUES
(1, 't1', 23, 'http://takhfifsensor.test/admin/banners/create1', 'bottom', '2021-08-28 14:26:57', '2021-08-28 14:26:57'),
(2, 't2', 24, 'http://takhfifsensor.test/admin/banners/create2', 'long_top', '2021-08-28 14:27:37', '2021-08-28 14:54:58'),
(3, 't3', 25, 'http://takhfifsensor.test/admin/banners/create3', 'short_top', '2021-08-28 14:27:46', '2021-08-28 14:54:56'),
(6, 'tdgsg', 30, 'http://takhfifsensor.test/admin/banners/create66446', 'bottom', '2021-08-29 18:13:16', '2021-08-29 18:13:16');

-- --------------------------------------------------------

--
-- Table structure for table `blacklists`
--

CREATE TABLE `blacklists` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `date` date DEFAULT NULL,
  `text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `name`, `slug`, `image_id`, `created_at`, `updated_at`) VALUES
(1, 'برند', 'test', 9, '2021-08-25 14:11:25', '2021-08-26 17:11:39'),
(3, 't2', 't2', 31, '2021-08-29 18:20:10', '2021-08-29 18:20:10'),
(4, 't3', 't3', 32, '2021-08-29 18:20:17', '2021-08-29 18:20:17'),
(5, 't4', 't4', 33, '2021-08-29 18:20:35', '2021-08-29 18:20:35'),
(6, 't5', 't5', 34, '2021-08-29 18:20:44', '2021-08-29 18:20:44'),
(7, 't6', 't6', 35, '2021-08-29 18:20:58', '2021-08-29 18:20:58'),
(8, 't7', 't7', 36, '2021-08-29 18:21:10', '2021-08-29 18:21:10');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` bigint(20) UNSIGNED DEFAULT NULL,
  `level` enum('1','2','3') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `parent_id`, `level`, `created_at`, `updated_at`) VALUES
(8, 'کالای دیجیتال', 'کالای-دیجیتال', NULL, '1', '2021-08-23 15:31:19', '2021-08-23 15:31:19'),
(9, 'گوشی موبایل', 'گوشی-موبایل', 8, '2', '2021-08-23 15:31:40', '2021-08-23 15:31:40'),
(10, 'سامسونگ', 'سامسونگ', 9, '3', '2021-08-23 15:32:10', '2021-08-23 16:32:00');

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `province_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `province_id`, `name`, `created_at`, `updated_at`) VALUES
(1, 1, 'تبريز', NULL, NULL),
(2, 1, 'كندوان', NULL, NULL),
(3, 1, 'بندر شرفخانه', NULL, NULL),
(4, 1, 'مراغه', NULL, NULL),
(5, 1, 'ميانه', NULL, NULL),
(6, 1, 'شبستر', NULL, NULL),
(7, 1, 'مرند', NULL, NULL),
(8, 1, 'جلفا', NULL, NULL),
(9, 1, 'سراب', NULL, NULL),
(10, 1, 'هاديشهر', NULL, NULL),
(11, 1, 'بناب', NULL, NULL),
(12, 1, 'كليبر', NULL, NULL),
(13, 1, 'تسوج', NULL, NULL),
(14, 1, 'اهر', NULL, NULL),
(15, 1, 'هريس', NULL, NULL),
(16, 1, 'عجبشير', NULL, NULL),
(17, 1, 'هشترود', NULL, NULL),
(18, 1, 'ملكان', NULL, NULL),
(19, 1, 'بستان آباد', NULL, NULL),
(20, 1, 'ورزقان', NULL, NULL),
(21, 1, 'اسكو', NULL, NULL),
(22, 1, 'آذر شهر', NULL, NULL),
(23, 1, 'قره آغاج', NULL, NULL),
(24, 1, 'ممقان', NULL, NULL),
(25, 1, 'صوفیان', NULL, NULL),
(26, 1, 'ایلخچی', NULL, NULL),
(27, 1, 'خسروشهر', NULL, NULL),
(28, 1, 'باسمنج', NULL, NULL),
(29, 1, 'سهند', NULL, NULL),
(30, 2, 'اروميه', NULL, NULL),
(31, 2, 'نقده', NULL, NULL),
(32, 2, 'ماكو', NULL, NULL),
(33, 2, 'تكاب', NULL, NULL),
(34, 2, 'خوي', NULL, NULL),
(35, 2, 'مهاباد', NULL, NULL),
(36, 2, 'سر دشت', NULL, NULL),
(37, 2, 'چالدران', NULL, NULL),
(38, 2, 'بوكان', NULL, NULL),
(39, 2, 'مياندوآب', NULL, NULL),
(40, 2, 'سلماس', NULL, NULL),
(41, 2, 'شاهين دژ', NULL, NULL),
(42, 2, 'پيرانشهر', NULL, NULL),
(43, 2, 'سيه چشمه', NULL, NULL),
(44, 2, 'اشنويه', NULL, NULL),
(45, 2, 'چایپاره', NULL, NULL),
(46, 2, 'پلدشت', NULL, NULL),
(47, 2, 'شوط', NULL, NULL),
(48, 3, 'اردبيل', NULL, NULL),
(49, 3, 'سرعين', NULL, NULL),
(50, 3, 'بيله سوار', NULL, NULL),
(51, 3, 'پارس آباد', NULL, NULL),
(52, 3, 'خلخال', NULL, NULL),
(53, 3, 'مشگين شهر', NULL, NULL),
(54, 3, 'مغان', NULL, NULL),
(55, 3, 'نمين', NULL, NULL),
(56, 3, 'نير', NULL, NULL),
(57, 3, 'كوثر', NULL, NULL),
(58, 3, 'كيوي', NULL, NULL),
(59, 3, 'گرمي', NULL, NULL),
(60, 4, 'اصفهان', NULL, NULL),
(61, 4, 'فريدن', NULL, NULL),
(62, 4, 'فريدون شهر', NULL, NULL),
(63, 4, 'فلاورجان', NULL, NULL),
(64, 4, 'گلپايگان', NULL, NULL),
(65, 4, 'دهاقان', NULL, NULL),
(66, 4, 'نطنز', NULL, NULL),
(67, 4, 'نايين', NULL, NULL),
(68, 4, 'تيران', NULL, NULL),
(69, 4, 'كاشان', NULL, NULL),
(70, 4, 'فولاد شهر', NULL, NULL),
(71, 4, 'اردستان', NULL, NULL),
(72, 4, 'سميرم', NULL, NULL),
(73, 4, 'درچه', NULL, NULL),
(74, 4, 'کوهپایه', NULL, NULL),
(75, 4, 'مباركه', NULL, NULL),
(76, 4, 'شهرضا', NULL, NULL),
(77, 4, 'خميني شهر', NULL, NULL),
(78, 4, 'شاهين شهر', NULL, NULL),
(79, 4, 'نجف آباد', NULL, NULL),
(80, 4, 'دولت آباد', NULL, NULL),
(81, 4, 'زرين شهر', NULL, NULL),
(82, 4, 'آران و بيدگل', NULL, NULL),
(83, 4, 'باغ بهادران', NULL, NULL),
(84, 4, 'خوانسار', NULL, NULL),
(85, 4, 'مهردشت', NULL, NULL),
(86, 4, 'علويجه', NULL, NULL),
(87, 4, 'عسگران', NULL, NULL),
(88, 4, 'نهضت آباد', NULL, NULL),
(89, 4, 'حاجي آباد', NULL, NULL),
(90, 4, 'تودشک', NULL, NULL),
(91, 4, 'ورزنه', NULL, NULL),
(92, 6, 'ايلام', NULL, NULL),
(93, 6, 'مهران', NULL, NULL),
(94, 6, 'دهلران', NULL, NULL),
(95, 6, 'آبدانان', NULL, NULL),
(96, 6, 'شيروان چرداول', NULL, NULL),
(97, 6, 'دره شهر', NULL, NULL),
(98, 6, 'ايوان', NULL, NULL),
(99, 6, 'سرابله', NULL, NULL),
(100, 7, 'بوشهر', NULL, NULL),
(101, 7, 'تنگستان', NULL, NULL),
(102, 7, 'دشتستان', NULL, NULL),
(103, 7, 'دير', NULL, NULL),
(104, 7, 'ديلم', NULL, NULL),
(105, 7, 'كنگان', NULL, NULL),
(106, 7, 'گناوه', NULL, NULL),
(107, 7, 'ريشهر', NULL, NULL),
(108, 7, 'دشتي', NULL, NULL),
(109, 7, 'خورموج', NULL, NULL),
(110, 7, 'اهرم', NULL, NULL),
(111, 7, 'برازجان', NULL, NULL),
(112, 7, 'خارك', NULL, NULL),
(113, 7, 'جم', NULL, NULL),
(114, 7, 'کاکی', NULL, NULL),
(115, 7, 'عسلویه', NULL, NULL),
(116, 7, 'بردخون', NULL, NULL),
(117, 8, 'تهران', NULL, NULL),
(118, 8, 'ورامين', NULL, NULL),
(119, 8, 'فيروزكوه', NULL, NULL),
(120, 8, 'ري', NULL, NULL),
(121, 8, 'دماوند', NULL, NULL),
(122, 8, 'اسلامشهر', NULL, NULL),
(123, 8, 'رودهن', NULL, NULL),
(124, 8, 'لواسان', NULL, NULL),
(125, 8, 'بومهن', NULL, NULL),
(126, 8, 'تجريش', NULL, NULL),
(127, 8, 'فشم', NULL, NULL),
(128, 8, 'كهريزك', NULL, NULL),
(129, 8, 'پاكدشت', NULL, NULL),
(130, 8, 'چهاردانگه', NULL, NULL),
(131, 8, 'شريف آباد', NULL, NULL),
(132, 8, 'قرچك', NULL, NULL),
(133, 8, 'باقرشهر', NULL, NULL),
(134, 8, 'شهريار', NULL, NULL),
(135, 8, 'رباط كريم', NULL, NULL),
(136, 8, 'قدس', NULL, NULL),
(137, 8, 'ملارد', NULL, NULL),
(138, 9, 'شهركرد', NULL, NULL),
(139, 9, 'فارسان', NULL, NULL),
(140, 9, 'بروجن', NULL, NULL),
(141, 9, 'چلگرد', NULL, NULL),
(142, 9, 'اردل', NULL, NULL),
(143, 9, 'لردگان', NULL, NULL),
(144, 9, 'سامان', NULL, NULL),
(145, 10, 'قائن', NULL, NULL),
(146, 10, 'فردوس', NULL, NULL),
(147, 10, 'بيرجند', NULL, NULL),
(148, 10, 'نهبندان', NULL, NULL),
(149, 10, 'سربيشه', NULL, NULL),
(150, 10, 'طبس مسینا', NULL, NULL),
(151, 10, 'قهستان', NULL, NULL),
(152, 10, 'درمیان', NULL, NULL),
(153, 11, 'مشهد', NULL, NULL),
(154, 11, 'نيشابور', NULL, NULL),
(155, 11, 'سبزوار', NULL, NULL),
(156, 11, 'كاشمر', NULL, NULL),
(157, 11, 'گناباد', NULL, NULL),
(158, 11, 'طبس', NULL, NULL),
(159, 11, 'تربت حيدريه', NULL, NULL),
(160, 11, 'خواف', NULL, NULL),
(161, 11, 'تربت جام', NULL, NULL),
(162, 11, 'تايباد', NULL, NULL),
(163, 11, 'قوچان', NULL, NULL),
(164, 11, 'سرخس', NULL, NULL),
(165, 11, 'بردسكن', NULL, NULL),
(166, 11, 'فريمان', NULL, NULL),
(167, 11, 'چناران', NULL, NULL),
(168, 11, 'درگز', NULL, NULL),
(169, 11, 'كلات', NULL, NULL),
(170, 11, 'طرقبه', NULL, NULL),
(171, 11, 'سر ولایت', NULL, NULL),
(172, 12, 'بجنورد', NULL, NULL),
(173, 12, 'اسفراين', NULL, NULL),
(174, 12, 'جاجرم', NULL, NULL),
(175, 12, 'شيروان', NULL, NULL),
(176, 12, 'آشخانه', NULL, NULL),
(177, 12, 'گرمه', NULL, NULL),
(178, 12, 'ساروج', NULL, NULL),
(179, 13, 'اهواز', NULL, NULL),
(180, 13, 'ايرانشهر', NULL, NULL),
(181, 13, 'شوش', NULL, NULL),
(182, 13, 'آبادان', NULL, NULL),
(183, 13, 'خرمشهر', NULL, NULL),
(184, 13, 'مسجد سليمان', NULL, NULL),
(185, 13, 'ايذه', NULL, NULL),
(186, 13, 'شوشتر', NULL, NULL),
(187, 13, 'انديمشك', NULL, NULL),
(188, 13, 'سوسنگرد', NULL, NULL),
(189, 13, 'هويزه', NULL, NULL),
(190, 13, 'دزفول', NULL, NULL),
(191, 13, 'شادگان', NULL, NULL),
(192, 13, 'بندر ماهشهر', NULL, NULL),
(193, 13, 'بندر امام خميني', NULL, NULL),
(194, 13, 'اميديه', NULL, NULL),
(195, 13, 'بهبهان', NULL, NULL),
(196, 13, 'رامهرمز', NULL, NULL),
(197, 13, 'باغ ملك', NULL, NULL),
(198, 13, 'هنديجان', NULL, NULL),
(199, 13, 'لالي', NULL, NULL),
(200, 13, 'رامشیر', NULL, NULL),
(201, 13, 'حمیدیه', NULL, NULL),
(202, 13, 'دغاغله', NULL, NULL),
(203, 13, 'ملاثانی', NULL, NULL),
(204, 13, 'شادگان', NULL, NULL),
(205, 13, 'ویسی', NULL, NULL),
(206, 14, 'زنجان', NULL, NULL),
(207, 14, 'ابهر', NULL, NULL),
(208, 14, 'خدابنده', NULL, NULL),
(209, 14, 'كارم', NULL, NULL),
(210, 14, 'ماهنشان', NULL, NULL),
(211, 14, 'خرمدره', NULL, NULL),
(212, 14, 'ايجرود', NULL, NULL),
(213, 14, 'زرين آباد', NULL, NULL),
(214, 14, 'آب بر', NULL, NULL),
(215, 14, 'قيدار', NULL, NULL),
(216, 15, 'سمنان', NULL, NULL),
(217, 15, 'شاهرود', NULL, NULL),
(218, 15, 'گرمسار', NULL, NULL),
(219, 15, 'ايوانكي', NULL, NULL),
(220, 15, 'دامغان', NULL, NULL),
(221, 15, 'بسطام', NULL, NULL),
(222, 16, 'زاهدان', NULL, NULL),
(223, 16, 'چابهار', NULL, NULL),
(224, 16, 'خاش', NULL, NULL),
(225, 16, 'سراوان', NULL, NULL),
(226, 16, 'زابل', NULL, NULL),
(227, 16, 'سرباز', NULL, NULL),
(228, 16, 'نيكشهر', NULL, NULL),
(229, 16, 'ايرانشهر', NULL, NULL),
(230, 16, 'راسك', NULL, NULL),
(231, 16, 'ميرجاوه', NULL, NULL),
(232, 17, 'شيراز', NULL, NULL),
(233, 17, 'اقليد', NULL, NULL),
(234, 17, 'داراب', NULL, NULL),
(235, 17, 'فسا', NULL, NULL),
(236, 17, 'مرودشت', NULL, NULL),
(237, 17, 'خرم بيد', NULL, NULL),
(238, 17, 'آباده', NULL, NULL),
(239, 17, 'كازرون', NULL, NULL),
(240, 17, 'ممسني', NULL, NULL),
(241, 17, 'سپيدان', NULL, NULL),
(242, 17, 'لار', NULL, NULL),
(243, 17, 'فيروز آباد', NULL, NULL),
(244, 17, 'جهرم', NULL, NULL),
(245, 17, 'ني ريز', NULL, NULL),
(246, 17, 'استهبان', NULL, NULL),
(247, 17, 'لامرد', NULL, NULL),
(248, 17, 'مهر', NULL, NULL),
(249, 17, 'حاجي آباد', NULL, NULL),
(250, 17, 'نورآباد', NULL, NULL),
(251, 17, 'اردكان', NULL, NULL),
(252, 17, 'صفاشهر', NULL, NULL),
(253, 17, 'ارسنجان', NULL, NULL),
(254, 17, 'قيروكارزين', NULL, NULL),
(255, 17, 'سوريان', NULL, NULL),
(256, 17, 'فراشبند', NULL, NULL),
(257, 17, 'سروستان', NULL, NULL),
(258, 17, 'ارژن', NULL, NULL),
(259, 17, 'گويم', NULL, NULL),
(260, 17, 'داريون', NULL, NULL),
(261, 17, 'زرقان', NULL, NULL),
(262, 17, 'خان زنیان', NULL, NULL),
(263, 17, 'کوار', NULL, NULL),
(264, 17, 'ده بید', NULL, NULL),
(265, 17, 'باب انار/خفر', NULL, NULL),
(266, 17, 'بوانات', NULL, NULL),
(267, 17, 'خرامه', NULL, NULL),
(268, 17, 'خنج', NULL, NULL),
(269, 17, 'سیاخ دارنگون', NULL, NULL),
(270, 18, 'قزوين', NULL, NULL),
(271, 18, 'تاكستان', NULL, NULL),
(272, 18, 'آبيك', NULL, NULL),
(273, 18, 'بوئين زهرا', NULL, NULL),
(274, 19, 'قم', NULL, NULL),
(275, 5, 'طالقان', NULL, NULL),
(276, 5, 'نظرآباد', NULL, NULL),
(277, 5, 'اشتهارد', NULL, NULL),
(278, 5, 'هشتگرد', NULL, NULL),
(279, 5, 'كن', NULL, NULL),
(280, 5, 'آسارا', NULL, NULL),
(281, 5, 'شهرک گلستان', NULL, NULL),
(282, 5, 'اندیشه', NULL, NULL),
(283, 5, 'كرج', NULL, NULL),
(284, 5, 'نظر آباد', NULL, NULL),
(285, 5, 'گوهردشت', NULL, NULL),
(286, 5, 'ماهدشت', NULL, NULL),
(287, 5, 'مشکین دشت', NULL, NULL),
(288, 20, 'سنندج', NULL, NULL),
(289, 20, 'ديواندره', NULL, NULL),
(290, 20, 'بانه', NULL, NULL),
(291, 20, 'بيجار', NULL, NULL),
(292, 20, 'سقز', NULL, NULL),
(293, 20, 'كامياران', NULL, NULL),
(294, 20, 'قروه', NULL, NULL),
(295, 20, 'مريوان', NULL, NULL),
(296, 20, 'صلوات آباد', NULL, NULL),
(297, 20, 'حسن آباد', NULL, NULL),
(298, 21, 'كرمان', NULL, NULL),
(299, 21, 'راور', NULL, NULL),
(300, 21, 'بابك', NULL, NULL),
(301, 21, 'انار', NULL, NULL),
(302, 21, 'کوهبنان', NULL, NULL),
(303, 21, 'رفسنجان', NULL, NULL),
(304, 21, 'بافت', NULL, NULL),
(305, 21, 'سيرجان', NULL, NULL),
(306, 21, 'كهنوج', NULL, NULL),
(307, 21, 'زرند', NULL, NULL),
(308, 21, 'بم', NULL, NULL),
(309, 21, 'جيرفت', NULL, NULL),
(310, 21, 'بردسير', NULL, NULL),
(311, 22, 'كرمانشاه', NULL, NULL),
(312, 22, 'اسلام آباد غرب', NULL, NULL),
(313, 22, 'سر پل ذهاب', NULL, NULL),
(314, 22, 'كنگاور', NULL, NULL),
(315, 22, 'سنقر', NULL, NULL),
(316, 22, 'قصر شيرين', NULL, NULL),
(317, 22, 'گيلان غرب', NULL, NULL),
(318, 22, 'هرسين', NULL, NULL),
(319, 22, 'صحنه', NULL, NULL),
(320, 22, 'پاوه', NULL, NULL),
(321, 22, 'جوانرود', NULL, NULL),
(322, 22, 'شاهو', NULL, NULL),
(323, 23, 'ياسوج', NULL, NULL),
(324, 23, 'گچساران', NULL, NULL),
(325, 23, 'دنا', NULL, NULL),
(326, 23, 'دوگنبدان', NULL, NULL),
(327, 23, 'سي سخت', NULL, NULL),
(328, 23, 'دهدشت', NULL, NULL),
(329, 23, 'ليكك', NULL, NULL),
(330, 24, 'گرگان', NULL, NULL),
(331, 24, 'آق قلا', NULL, NULL),
(332, 24, 'گنبد كاووس', NULL, NULL),
(333, 24, 'علي آباد كتول', NULL, NULL),
(334, 24, 'مينو دشت', NULL, NULL),
(335, 24, 'تركمن', NULL, NULL),
(336, 24, 'كردكوي', NULL, NULL),
(337, 24, 'بندر گز', NULL, NULL),
(338, 24, 'كلاله', NULL, NULL),
(339, 24, 'آزاد شهر', NULL, NULL),
(340, 24, 'راميان', NULL, NULL),
(341, 25, 'رشت', NULL, NULL),
(342, 25, 'منجيل', NULL, NULL),
(343, 25, 'لنگرود', NULL, NULL),
(344, 25, 'رود سر', NULL, NULL),
(345, 25, 'تالش', NULL, NULL),
(346, 25, 'آستارا', NULL, NULL),
(347, 25, 'ماسوله', NULL, NULL),
(348, 25, 'آستانه اشرفيه', NULL, NULL),
(349, 25, 'رودبار', NULL, NULL),
(350, 25, 'فومن', NULL, NULL),
(351, 25, 'صومعه سرا', NULL, NULL),
(352, 25, 'بندرانزلي', NULL, NULL),
(353, 25, 'كلاچاي', NULL, NULL),
(354, 25, 'هشتپر', NULL, NULL),
(355, 25, 'رضوان شهر', NULL, NULL),
(356, 25, 'ماسال', NULL, NULL),
(357, 25, 'شفت', NULL, NULL),
(358, 25, 'سياهكل', NULL, NULL),
(359, 25, 'املش', NULL, NULL),
(360, 25, 'لاهیجان', NULL, NULL),
(361, 25, 'خشک بيجار', NULL, NULL),
(362, 25, 'خمام', NULL, NULL),
(363, 25, 'لشت نشا', NULL, NULL),
(364, 25, 'بندر کياشهر', NULL, NULL),
(365, 26, 'خرم آباد', NULL, NULL),
(366, 26, 'ماهشهر', NULL, NULL),
(367, 26, 'دزفول', NULL, NULL),
(368, 26, 'بروجرد', NULL, NULL),
(369, 26, 'دورود', NULL, NULL),
(370, 26, 'اليگودرز', NULL, NULL),
(371, 26, 'ازنا', NULL, NULL),
(372, 26, 'نور آباد', NULL, NULL),
(373, 26, 'كوهدشت', NULL, NULL),
(374, 26, 'الشتر', NULL, NULL),
(375, 26, 'پلدختر', NULL, NULL),
(376, 27, 'ساري', NULL, NULL),
(377, 27, 'آمل', NULL, NULL),
(378, 27, 'بابل', NULL, NULL),
(379, 27, 'بابلسر', NULL, NULL),
(380, 27, 'بهشهر', NULL, NULL),
(381, 27, 'تنكابن', NULL, NULL),
(382, 27, 'جويبار', NULL, NULL),
(383, 27, 'چالوس', NULL, NULL),
(384, 27, 'رامسر', NULL, NULL),
(385, 27, 'سواد كوه', NULL, NULL),
(386, 27, 'قائم شهر', NULL, NULL),
(387, 27, 'نكا', NULL, NULL),
(388, 27, 'نور', NULL, NULL),
(389, 27, 'بلده', NULL, NULL),
(390, 27, 'نوشهر', NULL, NULL),
(391, 27, 'پل سفيد', NULL, NULL),
(392, 27, 'محمود آباد', NULL, NULL),
(393, 27, 'فريدون كنار', NULL, NULL),
(394, 28, 'اراك', NULL, NULL),
(395, 28, 'آشتيان', NULL, NULL),
(396, 28, 'تفرش', NULL, NULL),
(397, 28, 'خمين', NULL, NULL),
(398, 28, 'دليجان', NULL, NULL),
(399, 28, 'ساوه', NULL, NULL),
(400, 28, 'سربند', NULL, NULL),
(401, 28, 'محلات', NULL, NULL),
(402, 28, 'شازند', NULL, NULL),
(403, 29, 'بندرعباس', NULL, NULL),
(404, 29, 'قشم', NULL, NULL),
(405, 29, 'كيش', NULL, NULL),
(406, 29, 'بندر لنگه', NULL, NULL),
(407, 29, 'بستك', NULL, NULL),
(408, 29, 'حاجي آباد', NULL, NULL),
(409, 29, 'دهبارز', NULL, NULL),
(410, 29, 'انگهران', NULL, NULL),
(411, 29, 'ميناب', NULL, NULL),
(412, 29, 'ابوموسي', NULL, NULL),
(413, 29, 'بندر جاسك', NULL, NULL),
(414, 29, 'تنب بزرگ', NULL, NULL),
(415, 29, 'بندر خمیر', NULL, NULL),
(416, 29, 'پارسیان', NULL, NULL),
(417, 29, 'قشم', NULL, NULL),
(418, 30, 'همدان', NULL, NULL),
(419, 30, 'ملاير', NULL, NULL),
(420, 30, 'تويسركان', NULL, NULL),
(421, 30, 'نهاوند', NULL, NULL),
(422, 30, 'كبودر اهنگ', NULL, NULL),
(423, 30, 'رزن', NULL, NULL),
(424, 30, 'اسدآباد', NULL, NULL),
(425, 30, 'بهار', NULL, NULL),
(426, 31, 'يزد', NULL, NULL),
(427, 31, 'تفت', NULL, NULL),
(428, 31, 'اردكان', NULL, NULL),
(429, 31, 'ابركوه', NULL, NULL),
(430, 31, 'ميبد', NULL, NULL),
(431, 31, 'طبس', NULL, NULL),
(432, 31, 'بافق', NULL, NULL),
(433, 31, 'مهريز', NULL, NULL),
(434, 31, 'اشكذر', NULL, NULL),
(435, 31, 'هرات', NULL, NULL),
(436, 31, 'خضرآباد', NULL, NULL),
(437, 31, 'شاهديه', NULL, NULL),
(438, 31, 'حمیدیه شهر', NULL, NULL),
(439, 31, 'سید میرزا', NULL, NULL),
(440, 31, 'زارچ', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `f_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('read','unread') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unread',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `files` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`files`)),
  `type` enum('image') COLLATE utf8mb4_unicode_ci NOT NULL,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `public_folder` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `private_folder` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`id`, `files`, `type`, `filename`, `public_folder`, `private_folder`, `created_at`, `updated_at`) VALUES
(1, '{\"original\":\"sliders\\/\\/6123d9683e1bb.jpg\"}', 'image', 'home-v4-background.jpg', 'sliders', NULL, '2021-08-23 17:22:48', '2021-08-23 17:22:48'),
(2, '{\"original\":\"sliders\\/\\/6123dc33f31be.jpg\"}', 'image', 'landing-v2-background.jpg', 'sliders', NULL, '2021-08-23 17:34:44', '2021-08-23 17:34:44'),
(7, '{\"original\":\"posts\\/\\/612601e8250f6.jpg\"}', 'image', '1-3.jpg', 'posts', NULL, '2021-08-25 08:40:08', '2021-08-25 08:40:08'),
(8, '{\"original\":\"posts\\/media\\/\\/6126054b0b930.png\"}', 'image', '4.png', 'posts/media', NULL, '2021-08-25 08:54:35', '2021-08-25 08:54:35'),
(9, '{\"original\":\"brands\\/\\/61264f8d96fcd.png\"}', 'image', '1.png', 'brands', NULL, '2021-08-25 14:11:25', '2021-08-25 14:11:25'),
(14, '{\"original\":\"products\\/\\/6127d022d7d6e.jpg\"}', 'image', '2.jpg', 'products', NULL, '2021-08-26 17:32:18', '2021-08-26 17:32:18'),
(19, '{\"original\":\"sliders\\/\\/612a2ce82ca50.jpg\"}', 'image', 'home-v11-background.jpg', 'sliders', NULL, '2021-08-28 12:32:40', '2021-08-28 12:32:40'),
(21, '{\"original\":\"sliders\\/\\/612a2d266ede4.png\"}', 'image', 'landing-v1-img-1.png', 'sliders', NULL, '2021-08-28 12:33:42', '2021-08-28 12:33:42'),
(23, '{\"original\":\"banners\\/\\/612a47b17227a.png\"}', 'image', 'full-width.png', 'banners', NULL, '2021-08-28 14:26:57', '2021-08-28 14:26:57'),
(24, '{\"original\":\"banners\\/\\/612a47d9f0936.jpg\"}', 'image', '3-2.jpg', 'banners', NULL, '2021-08-28 14:27:37', '2021-08-28 14:27:37'),
(25, '{\"original\":\"banners\\/\\/612a47e2ccd57.jpg\"}', 'image', '3-3.jpg', 'banners', NULL, '2021-08-28 14:27:46', '2021-08-28 14:27:46'),
(26, '{\"original\":\"posts\\/\\/612a722cba4f6.jpg\"}', 'image', '1-2.jpg', 'posts', NULL, '2021-08-28 17:28:12', '2021-08-28 17:28:12'),
(27, '{\"original\":\"posts\\/\\/612a724039a03.jpg\"}', 'image', '1-4.jpg', 'posts', NULL, '2021-08-28 17:28:32', '2021-08-28 17:28:32'),
(30, '{\"original\":\"banners\\/\\/612bce3c02013.jpg\"}', 'image', '9-2.jpg', 'banners', NULL, '2021-08-29 18:13:16', '2021-08-29 18:13:16'),
(31, '{\"original\":\"brands\\/\\/612bcfdadfbe0.png\"}', 'image', '2.png', 'brands', NULL, '2021-08-29 18:20:10', '2021-08-29 18:20:10'),
(32, '{\"original\":\"brands\\/\\/612bcfe155d97.png\"}', 'image', '3.png', 'brands', NULL, '2021-08-29 18:20:17', '2021-08-29 18:20:17'),
(33, '{\"original\":\"brands\\/\\/612bcff35e9c5.png\"}', 'image', '5.png', 'brands', NULL, '2021-08-29 18:20:35', '2021-08-29 18:20:35'),
(34, '{\"original\":\"brands\\/\\/612bcffc6e635.png\"}', 'image', '6.png', 'brands', NULL, '2021-08-29 18:20:44', '2021-08-29 18:20:44'),
(35, '{\"original\":\"brands\\/\\/612bd00ad46fe.png\"}', 'image', '8.png', 'brands', NULL, '2021-08-29 18:20:58', '2021-08-29 18:20:58'),
(36, '{\"original\":\"brands\\/\\/612bd0161abae.png\"}', 'image', '9.png', 'brands', NULL, '2021-08-29 18:21:10', '2021-08-29 18:21:10'),
(37, '{\"original\":\"posts\\/\\/612bd0897fb89.jpg\"}', 'image', '1-5.jpg', 'posts', NULL, '2021-08-29 18:23:05', '2021-08-29 18:23:05'),
(38, '{\"original\":\"posts\\/\\/612bd0abb052c.jpg\"}', 'image', '1-1.jpg', 'posts', NULL, '2021-08-29 18:23:39', '2021-08-29 18:23:39'),
(39, '{\"original\":\"posts\\/\\/612bd0c2a3b9b.png\"}', 'image', '4.png', 'posts', NULL, '2021-08-29 18:24:02', '2021-08-29 18:24:02'),
(40, '{\"original\":\"products\\/\\/612bd16cc5688.jpg\"}', 'image', 'big-1.jpg', 'products', NULL, '2021-08-29 18:26:52', '2021-08-29 18:26:52'),
(41, '{\"original\":\"products\\/\\/612bd189cb0da.jpg\"}', 'image', '1.jpg', 'products', NULL, '2021-08-29 18:27:21', '2021-08-29 18:27:21'),
(42, '{\"original\":\"products\\/\\/612bd1b853945.jpg\"}', 'image', '14.jpg', 'products', NULL, '2021-08-29 18:28:08', '2021-08-29 18:28:08'),
(43, '{\"original\":\"products\\/\\/612bd1cf87648.jpg\"}', 'image', 'deals-3.jpg', 'products', NULL, '2021-08-29 18:28:31', '2021-08-29 18:28:31'),
(44, '{\"original\":\"products\\/\\/612bd1ee20d3b.png\"}', 'image', 'deals-3.png', 'products', NULL, '2021-08-29 18:29:02', '2021-08-29 18:29:02'),
(45, '{\"original\":\"products\\/\\/612bd21435d5d.png\"}', 'image', 'landing-1.2.png', 'products', NULL, '2021-08-29 18:29:40', '2021-08-29 18:29:40'),
(46, '{\"original\":\"products\\/\\/612bd23318c49.jpg\"}', 'image', 'card-1.jpg', 'products', NULL, '2021-08-29 18:30:11', '2021-08-29 18:30:11'),
(47, '{\"original\":\"products\\/\\/612bd24e30cbe.jpg\"}', 'image', 'card-5.jpg', 'products', NULL, '2021-08-29 18:30:38', '2021-08-29 18:30:38'),
(48, '{\"original\":\"products\\/\\/612bd29c63ebe.jpg\"}', 'image', '6-1-6-center.jpg', 'products', NULL, '2021-08-29 18:31:56', '2021-08-29 18:31:56'),
(49, '{\"original\":\"products\\/\\/612bd2f77db86.jpg\"}', 'image', 'card-4.jpg', 'products', NULL, '2021-08-29 18:33:27', '2021-08-29 18:33:27'),
(50, '{\"original\":\"products\\/\\/612bd32080335.png\"}', 'image', 'sports-1.png', 'products', NULL, '2021-08-29 18:34:08', '2021-08-29 18:34:08'),
(51, '{\"original\":\"products\\/\\/612bd3436858c.jpg\"}', 'image', 'xs-2.jpg', 'products', NULL, '2021-08-29 18:34:43', '2021-08-29 18:34:43'),
(52, '{\"original\":\"products\\/\\/612bd365d10fe.jpg\"}', 'image', 'xs-4.jpg', 'products', NULL, '2021-08-29 18:35:17', '2021-08-29 18:35:17'),
(53, '{\"original\":\"products\\/\\/612bd3873378e.jpg\"}', 'image', 'xs-5.jpg', 'products', NULL, '2021-08-29 18:35:51', '2021-08-29 18:35:51');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2012_06_05_103941_create_media_table', 1),
(2, '2014_10_12_000000_create_users_table', 1),
(3, '2021_07_13_001404_create_users_codes_table', 1),
(4, '2021_08_23_143934_create_categories_table', 1),
(5, '2021_08_23_144201_create_sliders_table', 1),
(6, '2021_07_27_165840_create_blacklists_table', 2),
(7, '2021_08_25_010716_create_posts_categories_table', 3),
(8, '2021_08_25_010941_create_posts_table', 3),
(9, '2021_08_25_121600_create_posts_media_table', 3),
(10, '2021_08_25_132903_create_brands_table', 4),
(11, '2021_08_25_140909_create_products_table', 5),
(12, '2021_08_25_190151_create_products_gallery_table', 5),
(13, '2021_08_27_213426_create_products_media_table', 6),
(14, '2021_08_28_173911_create_banners_table', 7),
(15, '2021_08_29_174122_create_contact_us_table', 8),
(16, '2021_09_01_004047_create_show_categories_table', 9),
(17, '2021_09_01_231000_create_provinces_table', 10),
(18, '2021_09_01_231139_create_cities_table', 10);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `image_id` bigint(20) UNSIGNED DEFAULT NULL,
  `text` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `name`, `slug`, `category_id`, `image_id`, `text`, `status`, `created_at`, `updated_at`) VALUES
(1, 'test', 'test', 2, 7, '<p>test</p>', 'active', '2021-08-25 08:40:07', '2021-08-25 08:40:08'),
(2, 'test2', 'test2', 2, 26, '<p>tr</p>', 'active', '2021-08-28 17:28:12', '2021-08-28 17:28:12'),
(3, 'tedg', 'sgsg', 2, 27, '<p>fgfg</p>', 'active', '2021-08-28 17:28:32', '2021-08-28 17:28:32'),
(4, 'zgzg', 'gzgzgzg', 2, 37, '<p>gss</p>', 'active', '2021-08-29 18:23:05', '2021-08-29 18:23:05'),
(5, 'gzgzgz', 'zgzzgzgz', 2, 38, '<p>gzgz</p>', 'active', '2021-08-29 18:23:39', '2021-08-29 18:23:39'),
(6, 'zgzgaaaa', 'zgvvvaa', 2, 39, '<p>gd</p>', 'active', '2021-08-29 18:24:02', '2021-08-29 18:24:02');

-- --------------------------------------------------------

--
-- Table structure for table `posts_categories`
--

CREATE TABLE `posts_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts_categories`
--

INSERT INTO `posts_categories` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(2, 'test', 'test', '2021-08-25 08:37:25', '2021-08-25 08:37:25');

-- --------------------------------------------------------

--
-- Table structure for table `posts_media`
--

CREATE TABLE `posts_media` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL,
  `media_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts_media`
--

INSERT INTO `posts_media` (`id`, `post_id`, `media_id`, `created_at`, `updated_at`) VALUES
(1, 1, 8, '2021-08-25 08:54:35', '2021-08-25 08:54:35');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `brand_id` bigint(20) UNSIGNED NOT NULL,
  `image_id` bigint(20) UNSIGNED DEFAULT NULL,
  `price` bigint(20) UNSIGNED NOT NULL,
  `discount` int(10) UNSIGNED DEFAULT NULL,
  `feature` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `count` bigint(20) UNSIGNED NOT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL,
  `sale` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `slug`, `category_id`, `brand_id`, `image_id`, `price`, `discount`, `feature`, `text`, `count`, `status`, `sale`, `created_at`, `updated_at`) VALUES
(2, 'test', 'test', 10, 1, 14, 5000000, 20, '<p>test</p>', '<p>test</p>', 50, 'active', 5, '2021-08-26 17:32:18', '2021-08-26 17:32:18'),
(3, 'xb', 'xbxb', 10, 4, 40, 1000000, 2, '<p>dgz</p>', '<p>zgzg</p>', 20, 'active', 2, '2021-08-29 18:26:52', '2021-08-29 18:26:52'),
(4, 'xzvafgssg', 'zvzsgsg', 10, 7, 41, 500000, NULL, '<p>ggdgdg</p>', '<p>dgdgdgdg</p>', 50, 'active', 20, '2021-08-29 18:27:21', '2021-08-29 18:27:21'),
(5, 'xbzvzvhdhdh', 'zczzc', 10, 8, 42, 500000, NULL, '<p>gsgs</p>', '<p>sgsg</p>', 20, 'active', 15, '2021-08-29 18:28:08', '2021-08-29 18:28:08'),
(6, 'gxgxxxxxxxxxxxxx', 'gxgxxxxxxxxxxxxx', 10, 3, 43, 5000000, 5, '<p>zgzg</p>', '<p>zgzg</p>', 20, 'active', 23, '2021-08-29 18:28:31', '2021-08-29 18:28:31'),
(7, 'zvFSF', 'zvfsf', 10, 3, 44, 550000, NULL, '<p>gsgsgs</p>', '<p>sgsgsgsg</p>', 20, 'active', 5, '2021-08-29 18:29:02', '2021-08-29 18:29:02'),
(8, 'vsssssssssssss', 'vsssssssssssss', 10, 6, 45, 200000, NULL, '<p>agaga</p>', '<p>agag</p>', 20, 'active', 44, '2021-08-29 18:29:40', '2021-08-29 18:29:40'),
(9, 'vsvssvsvsvsasafsf', 'svsvsvsvsv', 10, 4, 46, 10000000, NULL, '<p>vzvz</p>', '<p>agagag</p>', 20, 'active', 4, '2021-08-29 18:30:11', '2021-08-29 18:30:11'),
(10, 'cbxbsfsf', 'cbxbsfsf', 10, 5, 47, 500000, NULL, '<p>agagagag</p>', '<p>agaggagaggag</p>', 20, 'active', 6, '2021-08-29 18:30:38', '2021-08-29 18:30:38'),
(11, 'zbbbbbbbbbbhshhf', 'zbbbbbbbbbbadafhhjrj', 10, 4, 48, 2000000, 5, '<p>dgsgs</p>', '<p>cbcbc</p>', 20, 'active', 8, '2021-08-29 18:31:56', '2021-08-29 18:31:56'),
(12, 'gzzhshsh', 'gzzhshsh', 10, 3, 49, 100000, NULL, '<p>faf</p>', '<p>agag</p>', 20, 'active', 1, '2021-08-29 18:33:27', '2021-08-29 18:33:27'),
(13, 'agagkgkakglj', 'kgagkakgk', 10, 4, 50, 20000000, NULL, '<p>agaga</p>', '<p>agag</p>', 20, 'active', 2, '2021-08-29 18:34:08', '2021-08-29 18:34:08'),
(14, 'ggzgzzgzgzzg', 'ggzgzzgzgzzg', 10, 6, 51, 5000000, NULL, '<p>FfFFgzgzgzg</p>', '<p>zgzg</p>', 50, 'active', 2, '2021-08-29 18:34:43', '2021-08-29 18:34:43'),
(15, 'joagojoajg', 'joagojoajg', 10, 3, 52, 5000000, NULL, '<p>zgzg</p>', '<p>zgzg</p>', 50, 'active', 5, '2021-08-29 18:35:17', '2021-08-29 18:35:17'),
(16, 'zgoooooooo', 'zgoooooooo', 10, 5, 53, 5000000, NULL, '<p>zzgzg</p>', '<p>ahfjfj</p>', 50, 'active', 0, '2021-08-29 18:35:51', '2021-08-29 18:35:51');

-- --------------------------------------------------------

--
-- Table structure for table `products_gallery`
--

CREATE TABLE `products_gallery` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `image_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products_media`
--

CREATE TABLE `products_media` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `media_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `provinces`
--

CREATE TABLE `provinces` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `provinces`
--

INSERT INTO `provinces` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'آذربايجان شرقي', NULL, NULL),
(2, 'آذربايجان غربي', NULL, NULL),
(3, 'اردبيل', NULL, NULL),
(4, 'اصفهان', NULL, NULL),
(5, 'البرز', NULL, NULL),
(6, 'ايلام', NULL, NULL),
(7, 'بوشهر', NULL, NULL),
(8, 'تهران', NULL, NULL),
(9, 'چهارمحال بختياري', NULL, NULL),
(10, 'خراسان جنوبي', NULL, NULL),
(11, 'خراسان رضوي', NULL, NULL),
(12, 'خراسان شمالي', NULL, NULL),
(13, 'خوزستان', NULL, NULL),
(14, 'زنجان', NULL, NULL),
(15, 'سمنان', NULL, NULL),
(16, 'سيستان و بلوچستان', NULL, NULL),
(17, 'فارس', NULL, NULL),
(18, 'قزوين', NULL, NULL),
(19, 'قم', NULL, NULL),
(20, 'كردستان', NULL, NULL),
(21, 'كرمان', NULL, NULL),
(22, 'كرمانشاه', NULL, NULL),
(23, 'كهكيلويه و بويراحمد', NULL, NULL),
(24, 'گلستان', NULL, NULL),
(25, 'گيلان', NULL, NULL),
(26, 'لرستان', NULL, NULL),
(27, 'مازندران', NULL, NULL),
(28, 'مركزي', NULL, NULL),
(29, 'هرمزگان', NULL, NULL),
(30, 'همدان', NULL, NULL),
(31, 'يزد', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `show_categories`
--

CREATE TABLE `show_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `show_categories`
--

INSERT INTO `show_categories` (`id`, `category_id`, `created_at`, `updated_at`) VALUES
(3, 10, '2021-09-01 11:05:30', '2021-09-01 11:05:30');

-- --------------------------------------------------------

--
-- Table structure for table `sliders`
--

CREATE TABLE `sliders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_id` bigint(20) UNSIGNED DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sliders`
--

INSERT INTO `sliders` (`id`, `name`, `image_id`, `url`, `created_at`, `updated_at`) VALUES
(1, 'تست1', 1, 'http://takhfifsensor.test/admin/sliders/create', '2021-08-23 17:22:48', '2021-08-23 17:22:48'),
(2, 'تست2', 2, 'http://takhfifsensor.test/admin/sliders', '2021-08-23 17:34:43', '2021-08-23 17:34:44'),
(3, 'تست3', 19, 'http://takhfifsensor.test/admin/sliders/3/edit', '2021-08-23 17:35:28', '2021-08-28 12:32:40'),
(5, 'تست4', 21, 'http://takhfifsensor.test/', '2021-08-28 12:33:20', '2021-08-28 12:33:42');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `f_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `l_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'inactive',
  `role` enum('admin','user') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `f_name`, `l_name`, `mobile`, `password`, `status`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'فرید', 'شیشه بری', '09123456789', '$2y$10$WkJWwNXRrRkNGj2j2aAUuup6eFujTF3YKDI9FxFFrjVSRbynxGTHG', 'active', 'admin', 'SzKoiW7sj8BcH4aYyFt4MkXqCjP1ozFlwHNH1TUwY6QJrKjGAH1VgRUxbk9P', '2021-08-23 18:05:51', '2021-08-26 09:08:39'),
(2, 'میترا', 'فلکیان', '09506898105', '$2y$10$6VurmDlXledMLGhxRHXg/.9lCDplUNVX1KS/OCmkBfbc6Dnf0SnZ.', 'active', 'user', NULL, '2021-08-23 18:10:48', '2021-08-23 18:10:48'),
(3, 'علی', 'کاظمی', '09269126102', '$2y$10$tZkcg1GUWGAXcb983yLmtuW5S31pEeAMjvDjsFmaVzNNtlB6rfGxC', 'active', 'user', NULL, '2021-08-24 07:05:07', '2021-08-24 07:05:07'),
(4, 'سارا', 'بیات', '09399796627', '$2y$10$VkDN8HKTjfx2nFoK3DsUYO.cBCNZrN6edXfD0YAq55SOdhVXo4tRK', 'active', 'user', NULL, '2021-08-24 07:05:29', '2021-08-24 07:05:29'),
(7, 'رژان', 'نیلی', '09892595990', '$2y$10$bqyXFNXycYKCIqKtR4eIo.SOL7SClpN0hLTNqo3sS/ACOGnlAqasm', 'active', 'user', 'vjDGrM3FFAProbvPOTzxbHpHioXQIpRolXIAVytcntqtxjQqDr7TXARdNUXn', '2021-08-24 18:42:53', '2021-08-29 18:22:02');

-- --------------------------------------------------------

--
-- Table structure for table `users_codes`
--

CREATE TABLE `users_codes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `active_code` varchar(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expire_active_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resend_active_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users_codes`
--

INSERT INTO `users_codes` (`id`, `user_id`, `active_code`, `expire_active_code`, `resend_active_code`, `created_at`, `updated_at`) VALUES
(2, 7, '916934', '1629831623', '1629830845', '2021-08-24 18:42:54', '2021-08-24 18:45:23');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `banners`
--
ALTER TABLE `banners`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `banners_name_unique` (`name`),
  ADD UNIQUE KEY `banners_url_unique` (`url`),
  ADD KEY `banners_image_id_foreign` (`image_id`);

--
-- Indexes for table `blacklists`
--
ALTER TABLE `blacklists`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `blacklists_user_id_unique` (`user_id`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `brands_name_unique` (`name`),
  ADD UNIQUE KEY `brands_slug_unique` (`slug`),
  ADD KEY `brands_image_id_foreign` (`image_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categories_name_unique` (`name`),
  ADD UNIQUE KEY `categories_slug_unique` (`slug`),
  ADD KEY `categories_parent_id_foreign` (`parent_id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cities_province_id_foreign` (`province_id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contact_us_user_id_foreign` (`user_id`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `posts_name_unique` (`name`),
  ADD UNIQUE KEY `posts_slug_unique` (`slug`),
  ADD KEY `posts_category_id_foreign` (`category_id`),
  ADD KEY `posts_image_id_foreign` (`image_id`);

--
-- Indexes for table `posts_categories`
--
ALTER TABLE `posts_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `posts_categories_name_unique` (`name`),
  ADD UNIQUE KEY `posts_categories_slug_unique` (`slug`);

--
-- Indexes for table `posts_media`
--
ALTER TABLE `posts_media`
  ADD PRIMARY KEY (`id`),
  ADD KEY `posts_media_post_id_foreign` (`post_id`),
  ADD KEY `posts_media_media_id_foreign` (`media_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `products_name_unique` (`name`),
  ADD UNIQUE KEY `products_slug_unique` (`slug`),
  ADD KEY `products_category_id_foreign` (`category_id`),
  ADD KEY `products_brand_id_foreign` (`brand_id`),
  ADD KEY `products_image_id_foreign` (`image_id`);

--
-- Indexes for table `products_gallery`
--
ALTER TABLE `products_gallery`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_gallery_product_id_foreign` (`product_id`),
  ADD KEY `products_gallery_image_id_foreign` (`image_id`);

--
-- Indexes for table `products_media`
--
ALTER TABLE `products_media`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_media_product_id_foreign` (`product_id`),
  ADD KEY `products_media_media_id_foreign` (`media_id`);

--
-- Indexes for table `provinces`
--
ALTER TABLE `provinces`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `show_categories`
--
ALTER TABLE `show_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `show_categories_category_id_unique` (`category_id`);

--
-- Indexes for table `sliders`
--
ALTER TABLE `sliders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sliders_name_unique` (`name`),
  ADD UNIQUE KEY `sliders_url_unique` (`url`),
  ADD KEY `sliders_image_id_foreign` (`image_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_mobile_unique` (`mobile`);

--
-- Indexes for table `users_codes`
--
ALTER TABLE `users_codes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_codes_user_id_unique` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `banners`
--
ALTER TABLE `banners`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `blacklists`
--
ALTER TABLE `blacklists`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=441;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `media`
--
ALTER TABLE `media`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `posts_categories`
--
ALTER TABLE `posts_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `posts_media`
--
ALTER TABLE `posts_media`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `products_gallery`
--
ALTER TABLE `products_gallery`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products_media`
--
ALTER TABLE `products_media`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `provinces`
--
ALTER TABLE `provinces`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `show_categories`
--
ALTER TABLE `show_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sliders`
--
ALTER TABLE `sliders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users_codes`
--
ALTER TABLE `users_codes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `banners`
--
ALTER TABLE `banners`
  ADD CONSTRAINT `banners_image_id_foreign` FOREIGN KEY (`image_id`) REFERENCES `media` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `blacklists`
--
ALTER TABLE `blacklists`
  ADD CONSTRAINT `blacklists_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `brands`
--
ALTER TABLE `brands`
  ADD CONSTRAINT `brands_image_id_foreign` FOREIGN KEY (`image_id`) REFERENCES `media` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `categories_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cities`
--
ALTER TABLE `cities`
  ADD CONSTRAINT `cities_province_id_foreign` FOREIGN KEY (`province_id`) REFERENCES `provinces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD CONSTRAINT `contact_us_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `posts_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `posts_image_id_foreign` FOREIGN KEY (`image_id`) REFERENCES `media` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `posts_media`
--
ALTER TABLE `posts_media`
  ADD CONSTRAINT `posts_media_media_id_foreign` FOREIGN KEY (`media_id`) REFERENCES `media` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `posts_media_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `products_image_id_foreign` FOREIGN KEY (`image_id`) REFERENCES `media` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `products_gallery`
--
ALTER TABLE `products_gallery`
  ADD CONSTRAINT `products_gallery_image_id_foreign` FOREIGN KEY (`image_id`) REFERENCES `media` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `products_gallery_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `products_media`
--
ALTER TABLE `products_media`
  ADD CONSTRAINT `products_media_media_id_foreign` FOREIGN KEY (`media_id`) REFERENCES `media` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `products_media_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `show_categories`
--
ALTER TABLE `show_categories`
  ADD CONSTRAINT `show_categories_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sliders`
--
ALTER TABLE `sliders`
  ADD CONSTRAINT `sliders_image_id_foreign` FOREIGN KEY (`image_id`) REFERENCES `media` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `users_codes`
--
ALTER TABLE `users_codes`
  ADD CONSTRAINT `users_codes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
